create
    definer = root@`%` function myfun(a int, b int) returns int deterministic
begin
	declare result int default 0;
	-- 存储a的阶乘
	declare temp1 int default 1;
	-- 存储b的阶乘
	declare temp2 int default 1; 
	-- 求a的阶乘
	while a >= 1 do 
		set temp1 := temp1 * a;
		set a := a - 1;
	end while;
	-- 求b的阶乘
	while b >= 1 do 
		set temp2 := temp2 * b;
		set b := b - 1;
	end while;
	-- 求a! + b!
	set result := temp1 + temp2;
	return result;
end;

