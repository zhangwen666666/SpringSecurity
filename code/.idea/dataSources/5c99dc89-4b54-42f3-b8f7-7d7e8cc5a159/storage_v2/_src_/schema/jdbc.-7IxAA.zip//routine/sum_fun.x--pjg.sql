create
    definer = root@`%` function sum_fun(n int) returns int deterministic
begin 
	declare result int default 0;
	declare temp2 int default 1; 
	while n > 0 do 
		if n % 2 = 0 then 
			set result := result + n;
		end if;
		set n := n - 1;
	end while;
	return result;
end;

