create
    definer = root@`%` procedure mypro(IN n int, OUT sum int)
BEGIN
	set sum := 0;
	while n>=0 DO
		if n % 2 = 0 then 
			set sum := sum + n;
		end if;
		set n := n-1;
	end while;
end;

