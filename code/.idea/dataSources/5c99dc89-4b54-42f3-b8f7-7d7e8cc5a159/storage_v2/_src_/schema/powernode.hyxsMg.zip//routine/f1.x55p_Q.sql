create
    definer = root@`%` function f1(n int) returns int deterministic
BEGIN
	declare sum int;
	set sum := 0;
	while n>0 DO
		if n % 2 = 0 THEN
			set sum := sum + n;
		end if;
		set n := n - 1;
	end while;
	return sum;
END;

