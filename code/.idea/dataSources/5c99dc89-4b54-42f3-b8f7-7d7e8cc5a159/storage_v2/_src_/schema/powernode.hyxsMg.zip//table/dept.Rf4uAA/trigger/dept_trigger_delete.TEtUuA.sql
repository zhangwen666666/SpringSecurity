create definer = root@`%` trigger dept_trigger_delete
    after delete
    on dept
    for each row
begin
	/*触发之后执行的SQL语句*/
	insert into oper_log(id,table_name,oper_type,oper_time,oper_id,oper_desc) VALUES
	(null,'dept','delete',now(),old.deptno,concat('删除数据：deptno=',old.deptno,',dname=',old.dname,',loc=',old.loc));
end;

