create
    definer = root@`%` procedure p4(IN sal int)
BEGIN
	select sal;
	set sal := sal*1.1;
END;

