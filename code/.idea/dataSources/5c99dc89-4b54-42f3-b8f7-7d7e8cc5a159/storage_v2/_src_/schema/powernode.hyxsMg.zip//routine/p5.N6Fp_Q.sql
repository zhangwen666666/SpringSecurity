create
    definer = root@`%` procedure p5(IN n int, OUT sum int)
BEGIN
	set sum := 0;
	REPEAT
		if n % 2 = 0 THEN
			set sum := sum + n;
		end if;
		set n := n - 1;
		until n <= 2
	end REPEAT;
END;

