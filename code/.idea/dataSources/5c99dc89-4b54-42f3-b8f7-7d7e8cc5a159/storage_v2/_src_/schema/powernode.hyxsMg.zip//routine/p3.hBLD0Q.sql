create
    definer = root@`%` procedure p3(OUT sal int, IN grade varchar(20))
begin 
	if sal > 10000 THEN
		set grade := '高收入';
	elseif sal >= 6000 THEN
		set grade := '中收入';
	else 
		set grade := '低收入';
	end if;
end;

