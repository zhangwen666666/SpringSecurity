create
    definer = root@`%` procedure p1()
begin
	select empno,ename,sal from emp;
END;

