create definer = root@`%` trigger dept_tirgger_update
    after update
    on dept
    for each row
begin
	/*触发后执行的SQL语句*/
	insert into oper_log(id,table_name,oper_type,oper_time,oper_id,oper_desc) VALUES
	(null,'dept','update',now(),new.deptno,concat('更新数据,更新前：deptno=',old.deptno,',dname=',old.dname,',loc=',old.loc,'\t 更新后：deptno=',new.deptno,',dname=',new.dname,',loc=',new.loc));
end;

