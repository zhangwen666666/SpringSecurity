create definer = root@`%` trigger dept_trigger_insert
    after insert
    on dept
    for each row
BEGIN
	/*触发后执行的SQL语句*/
	insert into oper_log(id,table_name,oper_type,oper_time,oper_id,oper_desc) VALUES
	(null,'dept','inset',now(),new.deptno,concat('插入数据：deptno=',new.deptno,',dname=',new.dname,',loc=',new.loc));
END;

