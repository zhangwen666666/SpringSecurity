create
    definer = root@`%` procedure p2()
BEGIN
	declare id int;
	DECLARE sal DOUBLE default 0.0;
	DECLARE ecount int default 0;
	select count(*) into ecount from emp;
	set sal = 1314.520;
	set id = 20;
	select ecount,sal,id;
END;

