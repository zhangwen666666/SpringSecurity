create
    definer = root@`%` procedure p6()
BEGIN
	/*声明局部变量，必须在游标变量之前*/
	declare no int;
	declare name varchar(255);
	
	/*声明游标变量*/
	declare dept_cursor cursor for select deptno,dname from dept;
	
	/*处理异常*/
	DECLARE EXIT HANDLER FOR NOT found CLOSE dept_cursor;
	
	/*打开游标*/
	open dept_cursor;
	
	/*创建新表newdept*/
	drop table if exists newdept;
	create table newdept(
		no int primary key,
		name varchar(255) not null
	);
	
	/*通过游标变量取数据*/
	while true DO
		fetch dept_cursor into no,name;
		insert into newdept(no,name) values(no,name);
	end while;
	
	/*关闭游标*/
	close dept_cursor;
END;

